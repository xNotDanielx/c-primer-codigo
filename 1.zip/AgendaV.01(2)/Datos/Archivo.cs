﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Entidades;

namespace Datos
{
    public class Archivo
    {
        String ruta = "contactosFamiliar.txt";

        public String guardar(ContactoFamiliar c)
        {
            StreamWriter sw = new StreamWriter(ruta, true);
            sw.WriteLine(c.ToString());
            sw.Close();
            return "se guardo... waos";
        }



    }
}
