﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class ServicioContactoEmpresarial : IContacto<ContactoEmpresarial>
    {
        List<ContactoEmpresarial> contactoEmpresarials;
        public ServicioContactoEmpresarial()
        {
            contactoEmpresarials = new List<ContactoEmpresarial>();
        }
        public string Add(ContactoEmpresarial contacto)
        {
            try
            {
                if (contacto == null) { return $"Error al guardar el contacto ..."; }
                contactoEmpresarials.Add(contacto);
                return $"contacto {contacto.Nombre} guardado...";
            }
            catch (Exception)
            {
                return $"Error al guardar el contacto ...";
            }
        }

        public bool DeleteContact(ContactoEmpresarial contacto)
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
            return true;
        }

        public bool Exist(ContactoEmpresarial contacto)
        {
            throw new NotImplementedException();
        }

        public List<ContactoEmpresarial> GetAll()
        {
            throw new NotImplementedException();
        }

        public List<ContactoEmpresarial> GetByName(string name)
        {
            throw new NotImplementedException();
        }

        public void GetByPhone(ContactoEmpresarial phone)
        {
            int i = 2;
            foreach (var item in contactoEmpresarials)
            {

                Console.Clear();
                Console.SetCursorPosition(30, 3); Console.Write("Lista de contactos");
                Console.SetCursorPosition(30, 5); Console.Write("ID");
                Console.SetCursorPosition(35, 5); Console.Write("NOMBRE");
                Console.SetCursorPosition(45, 5); Console.Write("TELEFONO");
                Console.SetCursorPosition(60, 5); Console.Write("FECHA");
                if (phone.Telefono == item.Telefono)
                {
                    Console.SetCursorPosition(30, 5 + i); Console.Write(item.Id);
                    Console.SetCursorPosition(35, 5 + i); Console.Write(item.Nombre);
                    Console.SetCursorPosition(45, 5 + i); Console.Write(item.Telefono);
                    Console.SetCursorPosition(60, 5 + i); Console.Write(item.FechaNacimiento.ToShortDateString());
                    Console.SetCursorPosition(75, 5 + i); Console.Write(item.Correo);
                    i++;
                }
            }
        }

        public bool Update(ContactoEmpresarial contacto)
        {
            throw new NotImplementedException();
        }
    }
}
