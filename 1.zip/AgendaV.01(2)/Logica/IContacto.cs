﻿

using Entidades;
using System.Collections.Generic;

namespace Logica
{
    public interface IContacto<T>
    {
        string Add(T contacto);
        List<T> GetAll();
        bool DeleteContact(T contacto);
        bool Update(T contacto);
        void GetByPhone(T phone);
        List<T> GetByName(string name);
        bool Exist(T contacto);
    }
}
