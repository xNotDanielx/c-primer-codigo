﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class ServicioContactoFamiliar : IContacto<ContactoFamiliar>
    {
        List<ContactoFamiliar> contactoFamiliars;
        public ServicioContactoFamiliar()
        {
            contactoFamiliars = new List<ContactoFamiliar>();
        }

        public string Add(ContactoFamiliar contacto)
        {
            //validar
            try
            {
                if(contacto == null) { return $"Error al guardar el contacto ..."; }
                contactoFamiliars.Add(contacto);
                return $"contacto {contacto.Nombre} guardado...";
            }
            catch (Exception)
            {
                return $"Error al guardar el contacto ...";
            }
            
        }

        public bool DeleteContact(ContactoFamiliar contacto)
        {
            try
            {
                if (contactoFamiliars == null)
                {
                    Console.WriteLine("No hay datos en los contactos familiares...");
                    return false;
                }
                else
                {
                    if (contacto == null)
                    {
                        Console.WriteLine("digite un contacto valido...");
                        return false;
                    }
                    else
                    {
                        foreach(var item in contactoFamiliars)
                        {
                            if (contacto.Telefono == item.Telefono)
                            {
                                contactoFamiliars.Remove(item);
                                
                            }
                        }
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Exist(ContactoFamiliar contacto)
        {
            bool exist = false;
            foreach (var item in contactoFamiliars)
            {
                if(item.Equals(contacto)) { exist=true; }
            }
            
            return exist;
        }

        public List<ContactoFamiliar> GetAll()
        {
            if (contactoFamiliars.Count == 0) return null;

            return contactoFamiliars;
        }

        public List<ContactoFamiliar> GetByName(string name)
        {
            throw new NotImplementedException();
        }

        public void GetByPhone(ContactoFamiliar phone)
        {
            int i = 2;
            foreach (var item in contactoFamiliars)
            {

                Console.Clear();
                Console.SetCursorPosition(30, 3); Console.Write("Lista de contactos");
                Console.SetCursorPosition(30, 5); Console.Write("ID");
                Console.SetCursorPosition(35, 5); Console.Write("NOMBRE");
                Console.SetCursorPosition(45, 5); Console.Write("TELEFONO");
                Console.SetCursorPosition(60, 5); Console.Write("FECHA");
                if (phone.Telefono == item.Telefono)
                {
                    Console.SetCursorPosition(30, 5 + i); Console.Write(item.Id);
                    Console.SetCursorPosition(35, 5 + i); Console.Write(item.Nombre);
                    Console.SetCursorPosition(45, 5 + i); Console.Write(item.Telefono);
                    Console.SetCursorPosition(60, 5 + i); Console.Write(item.FechaNacimiento.ToShortDateString());
                    i++;
                }
            }
        }

        public bool Update(ContactoFamiliar contacto)
        {
            throw new NotImplementedException();
        }

        public void consultarTelefono(ContactoFamiliar contacto)
        {
            int i = 2;
            foreach (var item in contactoFamiliars) {
                
                Console.Clear();
                Console.SetCursorPosition(30, 3); Console.Write("Lista de contactos");
                Console.SetCursorPosition(30, 5); Console.Write("ID");
                Console.SetCursorPosition(35, 5); Console.Write("NOMBRE");
                Console.SetCursorPosition(45, 5); Console.Write("TELEFONO");
                Console.SetCursorPosition(60, 5); Console.Write("FECHA");
                if (contacto.Telefono == item.Telefono)
                {
                    Console.SetCursorPosition(30, 5 + i); Console.Write(item.Id);
                    Console.SetCursorPosition(35, 5 + i); Console.Write(item.Nombre);
                    Console.SetCursorPosition(45, 5 + i); Console.Write(item.Telefono);
                    Console.SetCursorPosition(60, 5 + i); Console.Write(item.FechaNacimiento.ToShortDateString());
                    i++;
                }
            }
        }
    }
}