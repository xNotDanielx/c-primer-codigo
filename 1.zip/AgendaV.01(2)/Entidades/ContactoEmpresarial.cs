﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ContactoEmpresarial:Persona
    {
        public ContactoEmpresarial() { }
        public DateTime FechaNacimiento { get; set; }
        public String Correo { get; set; }
        public ContactoEmpresarial(int id, string nombre, string telefono, DateTime fechaNacimiento, string correo) : base(id, nombre, telefono)
        {
            FechaNacimiento = fechaNacimiento;
            Correo = correo;
        }

        public override string ToString()
        {
            return $"{Id}; {Nombre}; {Telefono}; {FechaNacimiento.ToShortDateString()}; {Correo}";
        }
    }
}
