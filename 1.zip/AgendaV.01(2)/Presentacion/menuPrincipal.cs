﻿using Logica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Presentacion
{
    public class menuPrincipal
    {
        public void verMenu()
        {
            ServicioContactoFamiliar servicioContactoFamiliar = new ServicioContactoFamiliar();
            int op = 0;
            do
            {
                Console.Clear();
                Console.SetCursorPosition(30, 3); Console.WriteLine("***********menú principal***********");
                Console.SetCursorPosition(30, 6); Console.WriteLine("1 - Gestion Contacto Familiar");
                Console.SetCursorPosition(30, 7); Console.WriteLine("2 - Gestion Contaco Empresarial");
                Console.SetCursorPosition(30, 8); Console.WriteLine("0 - Salir");
                Console.SetCursorPosition(30, 9); Console.WriteLine("Que quieres hacer: ");
                Console.SetCursorPosition(48, 9); op = int.Parse(Console.ReadLine());
                opcion(op);
            }while(op != 0);
        }

        public void opcion(int op){
            switch(op)
            {
                case 1:
                    MenuGestionF();
                    break;
                case 2:
                    MenuGestionE();
                    break;
                case 0:
                    break;
               


            }
        
        }
        public void MenuGestionF()
        {
            int op = 0;
            var cap = new ContactoGUI();
            do
            {
                Console.Clear();
                Console.SetCursorPosition(30, 3); Console.WriteLine("***********menú Gestion Famiiar***********");
                Console.SetCursorPosition(30, 6); Console.WriteLine("1 - Agregar Contacto");
                Console.SetCursorPosition(30, 7); Console.WriteLine("2 - Modificar contacto");
                Console.SetCursorPosition(30, 8); Console.WriteLine("3 - Eliminar contacto");
                Console.SetCursorPosition(30, 9); Console.WriteLine("4 - Buscar contato por telefono");
                Console.SetCursorPosition(30, 10); Console.WriteLine("0 - Salir");
                Console.SetCursorPosition(30, 11); Console.WriteLine("Que quieres hacer: ");
                Console.SetCursorPosition(49, 11); op = int.Parse(Console.ReadLine());

                switch (op)
                {

                    case 1:
                        cap.CapturarF();
                        break;

                    case 3:
                        cap.DeleteF();
                        break;

                    case 4:
                        cap.GetByPhoneF();
                        break;

                }
            } while(op != 0);

            
        }
        public void MenuGestionE()
        {
            int op = 0;
            var cap = new ContactoGUI();
            do
            {
                Console.Clear();
                Console.SetCursorPosition(30, 3); Console.WriteLine("***********menú Gestion Famiiar***********");
                Console.SetCursorPosition(30, 6); Console.WriteLine("1 - Agregar Contacto");
                Console.SetCursorPosition(30, 7); Console.WriteLine("2 - Modificar contacto");
                Console.SetCursorPosition(30, 7); Console.WriteLine("3 - Eliminar contacto");
                Console.SetCursorPosition(30, 7); Console.WriteLine("4 - Buscar contato por telefono");
                Console.SetCursorPosition(30, 8); Console.WriteLine("0 - Salir");
                Console.SetCursorPosition(30, 9); Console.WriteLine("Que quieres hacer: ");
                Console.SetCursorPosition(48, 9); op = int.Parse(Console.ReadLine());

                switch (op)
                {

                    case 1:
                        cap.CapturarE();
                        break;

                    case 3:
                        //cap.DeleteE();
                        break;

                    case 4:
                        cap.GetByPhoneE();
                        break;

                }
            } while (op != 0);
        }
    }
}
