﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var contactoFamiliarGui= new ContactoFamiliarGUI();
            // contactoFamiliarGui.Capturar();
            // contactoFamiliarGui.Capturar();
            // contactoFamiliarGui.Consultar();
            // Console.ReadKey();
            var menuPrincipal = new menuPrincipal();
            menuPrincipal.verMenu();
        }
    }
}
