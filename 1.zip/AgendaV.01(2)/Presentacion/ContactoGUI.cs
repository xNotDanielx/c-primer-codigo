﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class ContactoGUI
    {
        ServicioContactoFamiliar servicioContactoFamiliar = new ServicioContactoFamiliar();
        ServicioContactoEmpresarial servicioContactoEmpresarial = new ServicioContactoEmpresarial();
        public void CapturarF()
        {

            var contacto = new ContactoFamiliar();
            int dia = 0, mes = 0, anio = 0;
            Console.Clear();
            Console.WriteLine("Captura de datos del contacto Familiar");
            contacto.Id =  new Random().Next(1,30);
            Console.Write("Nombre: ");  contacto.Nombre = Console.ReadLine();
            Console.Write("Telefono: ");  contacto.Telefono = Console.ReadLine();
            Console.WriteLine("Fecha de Nacimiento");
            Console.Write("Dia: "); dia =int.Parse( Console.ReadLine());
            Console.Write("MES: "); mes = int.Parse(Console.ReadLine());
            Console.Write("AÑO: "); anio = int.Parse(Console.ReadLine());
            contacto.FechaNacimiento = new DateTime(anio, mes, dia);
            var msg=servicioContactoFamiliar.Add(contacto);
            Console.WriteLine(msg);
            Console.ReadKey();
        }

        public void CapturarE()
        {

            var contacto = new ContactoEmpresarial();
            int dia = 0, mes = 0, anio = 0;
            Console.Clear();
            Console.WriteLine("Captura de datos del contacto empresarial");
            contacto.Id = new Random().Next(1, 30);
            Console.Write("Nombre: "); contacto.Nombre = Console.ReadLine();
            Console.Write("Telefono: "); contacto.Telefono = Console.ReadLine();
            Console.WriteLine("Fecha de Nacimiento");
            Console.Write("Dia: "); dia = int.Parse(Console.ReadLine());
            Console.Write("MES: "); mes = int.Parse(Console.ReadLine());
            Console.Write("AÑO: "); anio = int.Parse(Console.ReadLine());
            contacto.FechaNacimiento = new DateTime(anio, mes, dia);
            var msg = servicioContactoEmpresarial.Add(contacto);
            Console.WriteLine(msg);
            Console.ReadKey();
        }

        public void DeleteF()
        {
            var contacto = new ContactoFamiliar();
            Console.Clear();
            Console.WriteLine("Borrar Datos del contacto familiar");
            Console.WriteLine("Nombre el contacto: "); contacto.Telefono = Console.ReadLine();
            if (servicioContactoFamiliar.DeleteContact(contacto) == true)
            {
                Console.WriteLine("bacano >:)");
            }
            else
            {
                if (servicioContactoFamiliar.DeleteContact(contacto) == false)
                {
                    Console.WriteLine("No bacano >:(");
                }
                    
            }
            Console.ReadKey();
        }

        public void GetByPhoneF()
        {
            var contacto = new ContactoFamiliar();
            Console.Clear();
            Console.WriteLine("Buscar por telefono");
            Console.WriteLine("Telefono: "); contacto.Telefono = Console.ReadLine();
            servicioContactoFamiliar.GetByPhone(contacto);
            Console.ReadKey();

        }

        public void GetByPhoneE()

        {
            var contacto = new ContactoEmpresarial();
            Console.Clear();
            Console.WriteLine("Buscar por telefono");
            Console.WriteLine("Telefono: "); contacto.Telefono = Console.ReadLine();
            servicioContactoEmpresarial.GetByPhone(contacto);
            Console.ReadKey();

        }
    }
}
