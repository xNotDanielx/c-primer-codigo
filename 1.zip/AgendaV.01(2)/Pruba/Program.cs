﻿using Entidades;
using Logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pruba
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var contacto = new ContactoFamiliar(new Random().Next(1,30),"johnp","12345678",new DateTime(2000,2,5));
            //var servicio = new ServicioContactoFamiliar();
            //var msg = servicio.Add(null);
            //Console.WriteLine(msg);            
            Datos.Archivo archivo= new Datos.Archivo();
            archivo.guardar(contacto);
            Console.ReadKey();
        }
    }
}
